// apiReq.d.ts
declare module 'modules/utility/api/apiReq' {
    export default function api(url: string, args: any)
}