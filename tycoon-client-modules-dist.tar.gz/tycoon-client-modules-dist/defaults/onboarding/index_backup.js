import SignInOnboard from './SignInOnboard'
import RegisterOnboard from './RegisterOnboard'

export {
    SignInOnboard,
    RegisterOnboard
}